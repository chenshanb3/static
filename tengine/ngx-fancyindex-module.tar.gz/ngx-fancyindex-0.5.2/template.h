/* Automagically generated, do not edit! */
static const u_char t01_head1[] = ""
"<!DOCTYPE html>"
"<html>"
"<head>"
"<meta http-equiv=\"content-type\" content=\"text/html; charset=utf-8\">"
"<meta name=\"viewport\" content=\"width=device-width\">"
"<style type=\"text/css\">"
"body,html {"
"background:#fff;"
"font-family:\"Bitstream Vera Sans\",\"Lucida Grande\","
"\"Lucida Sans Unicode\",Lucidux,Verdana,Lucida,sans-serif;"
"}"
"tr:nth-child(even) {"
"background:#f4f4f4;"
"}"
"th,td {"
"padding:0.1em 0.5em;"
"}"
"th {"
"text-align:left;"
"font-weight:bold;"
"background:#eee;"
"border-bottom:1px solid #aaa;"
"}"
"#list {"
"border:1px solid #aaa;"
"width:100%;"
"}"
"a {"
"color:#a33;"
"}"
"a:hover {"
"color:#e33;"
"}"
"</style>"
"\n"
;
static const u_char t02_head2[] = ""
"\n"
"<title>Index of "
;
static const u_char t03_head3[] = ""
"</title>"
"\n"
"</head>"
;
static const u_char t04_body1[] = ""
"<body>"
"<h1>Index of "
;
static const u_char t05_body2[] = ""
"</h1>"
"\n"
;
static const u_char t06_list1[] = ""
"<table id=\"list\">"
"<thead>"
"<tr>"
"<th style=\"width:55%\"><a href=\"?C=N&amp;O=A\">File Name</a>&nbsp;<a href=\"?C=N&amp;O=D\">&nbsp;&darr;&nbsp;</a></th>"
"<th style=\"width:20%\"><a href=\"?C=S&amp;O=A\">File Size</a>&nbsp;<a href=\"?C=S&amp;O=D\">&nbsp;&darr;&nbsp;</a></th>"
"<th style=\"width:25%\"><a href=\"?C=M&amp;O=A\">Date</a>&nbsp;<a href=\"?C=M&amp;O=D\">&nbsp;&darr;&nbsp;</a></th>"
"</tr>"
"</thead>"
"\n"
"<tbody>"
;
static const u_char t_parentdir_entry[] = ""
"<tr>"
"<td class=\"link\"><a href=\"../?C=N&amp;O=A\">Parent directory/</a></td>"
"<td class=\"size\">-</td>"
"<td class=\"date\">-</td>"
"</tr>"
"\n"
;
static const u_char t07_list2[] = ""
"</tbody>"
"</table>"
;
static const u_char t08_foot1[] = ""
"</body>"
"</html>"
;
#define NFI_TEMPLATE_SIZE (0 \
	+ nfi_sizeof_ssz(t01_head1) \
	+ nfi_sizeof_ssz(t02_head2) \
	+ nfi_sizeof_ssz(t03_head3) \
	+ nfi_sizeof_ssz(t04_body1) \
	+ nfi_sizeof_ssz(t05_body2) \
	+ nfi_sizeof_ssz(t06_list1) \
	+ nfi_sizeof_ssz(t_parentdir_entry) \
	+ nfi_sizeof_ssz(t07_list2) \
	+ nfi_sizeof_ssz(t08_foot1) \
	)
